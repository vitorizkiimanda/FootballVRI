package com.example.vitorizkiimanda.footballvri.Model.fromExample

import com.example.vitorizkiimanda.footballvri.Model.fromExample.Team

data class TeamResponse(
        val teams: List<Team>)